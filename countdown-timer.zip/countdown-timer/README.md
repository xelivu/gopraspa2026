# Countdown Timer

A Pen created on CodePen.

Original URL: [https://codepen.io/xelivu/pen/gbLgzQp](https://codepen.io/xelivu/pen/gbLgzQp).

A how-to for a countdown clock.